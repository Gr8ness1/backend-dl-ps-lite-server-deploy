const axios = require('axios');
require('dotenv').config();

async function askAI(prompt, propertyData = {}) {
  const fullPrompt = `
You are a real estate assistant. Based on the following property data and user question, respond clearly and helpfully.

Property Info:
Owner: ${propertyData.ownerName || 'N/A'}
Address: ${propertyData.mailingAddress || 'N/A'}
Legal: ${propertyData.legalDescription || 'N/A'}

User Question:
${prompt}
`;

  try {
    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-4',
        messages: [{ role: 'user', content: fullPrompt }],
      },
      {
        headers: {
          'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
          'Content-Type': 'application/json',
        },
      }
    );
    return response.data.choices[0].message.content.trim();
  } catch (error) {
    console.error('AI Error:', error.response?.data || error.message);
    return "Sorry, I couldn't process your request.";
  }
}

module.exports = { askAI };
