const axios = require('axios');
const cheerio = require('cheerio');

async function fetchPropertyData(accountNumber) {
  try {
    const url = `https://public.hcad.org/records/Property.asp?acct=${accountNumber}`;
    const { data } = await axios.get(url);
    const $ = cheerio.load(data);

    const ownerName = $('td:contains("Owner Name")').next().text().trim();
    const mailingAddress = $('td:contains("Mailing Address")').next().text().trim();
    const legalDescription = $('td:contains("Legal Description")').next().text().trim();

    return {
      accountNumber,
      ownerName,
      mailingAddress,
      legalDescription
    };
  } catch (error) {
    console.error('Error fetching property data:', error);
    return { error: 'Failed to retrieve data' };
  }
}

module.exports = { fetchPropertyData };
