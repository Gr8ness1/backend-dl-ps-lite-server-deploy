const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = path.resolve(__dirname, 'searches.db');
const db = new sqlite3.Database(dbPath);

function saveSearch(data, callback) {
  const stmt = db.prepare(`INSERT INTO searches 
    (accountNumber, ownerName, mailingAddress, legalDescription) 
    VALUES (?, ?, ?, ?)`);
  stmt.run(
    data.accountNumber,
    data.ownerName,
    data.mailingAddress,
    data.legalDescription,
    callback
  );
}

function getSearches(callback) {
  db.all("SELECT * FROM searches ORDER BY timestamp DESC", callback);
}

module.exports = { saveSearch, getSearches };
