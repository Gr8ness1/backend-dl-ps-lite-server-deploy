const express = require('express');
const cors = require('cors');
const app = express();
const port = 5000;

const { fetchPropertyData } = require('./scraper');

app.use(cors());

app.get('/api/properties', (req, res) => {
  res.json([
    { address: '123 Main St, Houston, TX', price: 250000, owner: 'John Doe' },
    { address: '456 Elm St, Houston, TX', price: 320000, owner: 'Jane Smith' },
    { address: '789 Oak St, Houston, TX', price: 280000, owner: 'Sam Johnson' }
  ]);
});

app.get('/api/property/:account', async (req, res) => {
  const account = req.params.account;
  const data = await fetchPropertyData(account);
  res.json(data);
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});


const bodyParser = require('body-parser');
const { saveSearch, getSearches } = require('./db');

app.use(bodyParser.json());

app.post('/api/searches', (req, res) => {
  saveSearch(req.body, function (err) {
    if (err) {
      console.error('DB Insert Error:', err);
      return res.status(500).json({ error: 'Failed to save search' });
    }
    res.json({ success: true });
  });
});

app.get('/api/searches', (req, res) => {
  getSearches(function (err, rows) {
    if (err) {
      console.error('DB Fetch Error:', err);
      return res.status(500).json({ error: 'Failed to fetch searches' });
    }
    res.json(rows);
  });
});


const { askAI } = require('./ai');

app.post('/api/ask-ai', async (req, res) => {
  const { prompt, property } = req.body;
  const answer = await askAI(prompt, property);
  res.json({ answer });
});
